/**
 * Comprehensive Symptom Database
 * Data sourced from WHO, CDC, NHS, Mayo Clinic, and peer-reviewed medical journals
 */

const symptomDatabase = {
  // ─── RESPIRATORY ────────────────────────────────────────────────────────────
  cough: {
    id: "cough",
    name: "Cough",
    category: "Respiratory",
    relatedConditions: [
      {
        name: "Common Cold",
        probability: "high",
        icd10: "J00",
        description: "Viral upper respiratory tract infection causing cough, runny nose, and mild fever.",
        symptoms: ["cough", "runny_nose", "sore_throat", "mild_fever", "sneezing"],
        urgency: "low",
        care: "Rest, fluids, OTC symptom relief. Usually resolves in 7–10 days.",
        prevention: "Frequent handwashing, avoid contact with infected persons, annual flu vaccination.",
        sources: ["WHO", "CDC", "NHS"]
      },
      {
        name: "Influenza (Flu)",
        probability: "medium",
        icd10: "J11",
        description: "Highly contagious viral infection causing sudden onset of fever, cough, and body aches.",
        symptoms: ["cough", "high_fever", "body_aches", "fatigue", "headache", "chills"],
        urgency: "medium",
        care: "Rest, fluids, antiviral medications (within 48 hrs). Seek medical care if high-risk.",
        prevention: "Annual flu vaccine, good hygiene practices, avoid crowded spaces during flu season.",
        sources: ["WHO", "CDC", "Mayo Clinic"]
      },
      {
        name: "COVID-19",
        probability: "medium",
        icd10: "U07.1",
        description: "Respiratory illness caused by SARS-CoV-2. Range from mild to severe.",
        symptoms: ["cough", "fever", "fatigue", "loss_of_taste", "loss_of_smell", "shortness_of_breath"],
        urgency: "medium",
        care: "Isolate, rest, fluids. Seek emergency care if breathing difficulty or chest pain occurs.",
        prevention: "COVID-19 vaccination, masking in crowded spaces, hand hygiene.",
        sources: ["WHO", "CDC", "NIH"]
      },
      {
        name: "Asthma",
        probability: "medium",
        icd10: "J45",
        description: "Chronic condition causing airways to narrow, swell, and produce extra mucus.",
        symptoms: ["cough", "wheezing", "shortness_of_breath", "chest_tightness"],
        urgency: "medium",
        care: "Use prescribed inhalers. Seek immediate care if severe breathing difficulty.",
        prevention: "Identify and avoid triggers, follow asthma action plan, regular check-ups.",
        sources: ["WHO", "NIH", "GINA Guidelines"]
      },
      {
        name: "Pneumonia",
        probability: "low",
        icd10: "J18",
        description: "Infection inflaming air sacs in one or both lungs.",
        symptoms: ["cough", "fever", "chills", "shortness_of_breath", "chest_pain", "fatigue"],
        urgency: "high",
        care: "Requires medical evaluation. Antibiotics for bacterial pneumonia. May need hospitalization.",
        prevention: "Pneumococcal and flu vaccines, hand hygiene, no smoking.",
        sources: ["WHO", "CDC", "NHS"]
      }
    ]
  },

  fever: {
    id: "fever",
    name: "Fever",
    category: "General",
    relatedConditions: [
      {
        name: "Viral Infection",
        probability: "high",
        icd10: "B34.9",
        description: "Fever is the body's natural response to fighting viral infections.",
        symptoms: ["fever", "fatigue", "body_aches", "headache"],
        urgency: "low",
        care: "Rest, hydration, OTC antipyretics (paracetamol/ibuprofen). Monitor temperature.",
        prevention: "Vaccination, hand hygiene, avoid close contact with infected individuals.",
        sources: ["WHO", "NHS", "Mayo Clinic"]
      },
      {
        name: "Bacterial Infection",
        probability: "medium",
        icd10: "A49.9",
        description: "Bacterial infections often cause high persistent fever requiring antibiotic treatment.",
        symptoms: ["fever", "localized_pain", "swelling", "redness", "chills"],
        urgency: "medium",
        care: "Seek medical evaluation for appropriate antibiotics. Do not self-medicate with antibiotics.",
        prevention: "Vaccinations, proper food hygiene, wound care, hand washing.",
        sources: ["WHO", "CDC", "NIH"]
      },
      {
        name: "Typhoid Fever",
        probability: "low",
        icd10: "A01.0",
        description: "Serious bacterial infection caused by Salmonella typhi, spread through contaminated food/water.",
        symptoms: ["fever", "headache", "abdominal_pain", "weakness", "loss_of_appetite", "rash"],
        urgency: "high",
        care: "Requires antibiotics. Hospitalization may be needed for severe cases.",
        prevention: "Typhoid vaccine, safe water, food hygiene, handwashing.",
        sources: ["WHO", "CDC"]
      },
      {
        name: "Malaria",
        probability: "low",
        icd10: "B54",
        description: "Parasitic disease spread by mosquito bites causing recurring fever cycles.",
        symptoms: ["fever", "chills", "sweats", "headache", "nausea", "vomiting", "muscle_pain"],
        urgency: "high",
        care: "Requires specific antimalarial drugs. Seek immediate medical care.",
        prevention: "Antimalarial prophylaxis when traveling, insect repellent, bed nets, eliminate standing water.",
        sources: ["WHO", "CDC", "RBM Partnership"]
      }
    ]
  },

  headache: {
    id: "headache",
    name: "Headache",
    category: "Neurological",
    relatedConditions: [
      {
        name: "Tension Headache",
        probability: "high",
        icd10: "G44.2",
        description: "Most common headache type — dull, pressing pain around the head, often from stress or poor posture.",
        symptoms: ["headache", "neck_pain", "shoulder_tension", "sensitivity_to_light"],
        urgency: "low",
        care: "OTC pain relievers, rest, stress management, hydration. Apply warm/cold compress.",
        prevention: "Stress management, regular sleep, good posture, stay hydrated.",
        sources: ["WHO", "Mayo Clinic", "NHS"]
      },
      {
        name: "Migraine",
        probability: "medium",
        icd10: "G43",
        description: "Intense throbbing headache often on one side, with nausea and sensitivity to light/sound.",
        symptoms: ["headache", "nausea", "vomiting", "sensitivity_to_light", "sensitivity_to_sound", "visual_disturbances"],
        urgency: "medium",
        care: "Rest in a dark quiet room. Triptans or OTC pain relievers. Consult doctor for recurring migraines.",
        prevention: "Identify and avoid triggers (stress, certain foods, hormonal changes), regular sleep, medication.",
        sources: ["WHO", "NIH", "American Migraine Foundation"]
      },
      {
        name: "Hypertensive Headache",
        probability: "medium",
        icd10: "I10",
        description: "Headache caused by severely elevated blood pressure — usually throbbing, at the back of the head.",
        symptoms: ["headache", "blurred_vision", "dizziness", "chest_pain", "shortness_of_breath"],
        urgency: "high",
        care: "Seek immediate medical care if BP is very high. Do not ignore sudden severe headaches.",
        prevention: "Regular BP monitoring, healthy diet, exercise, medication adherence, reduce salt intake.",
        sources: ["WHO", "American Heart Association", "NHS"]
      },
      {
        name: "Meningitis",
        probability: "low",
        icd10: "G03.9",
        description: "Inflammation of brain/spinal cord membranes — severe headache with stiff neck and fever is a medical emergency.",
        symptoms: ["headache", "stiff_neck", "high_fever", "sensitivity_to_light", "nausea", "vomiting", "rash"],
        urgency: "emergency",
        care: "EMERGENCY — Call emergency services immediately. Requires IV antibiotics/antivirals in hospital.",
        prevention: "Meningococcal, pneumococcal, and Hib vaccines; avoid sharing utensils; good hygiene.",
        sources: ["WHO", "CDC", "NHS"]
      }
    ]
  },

  chest_pain: {
    id: "chest_pain",
    name: "Chest Pain",
    category: "Cardiovascular",
    relatedConditions: [
      {
        name: "Angina",
        probability: "medium",
        icd10: "I20",
        description: "Chest pain caused by reduced blood flow to the heart, often triggered by exertion.",
        symptoms: ["chest_pain", "shortness_of_breath", "fatigue", "pain_radiating_to_arm"],
        urgency: "high",
        care: "Sit or lie down. Use prescribed nitrates. Seek medical evaluation urgently.",
        prevention: "Heart-healthy diet, regular exercise, no smoking, manage cholesterol and BP.",
        sources: ["WHO", "American Heart Association", "ESC Guidelines"]
      },
      {
        name: "Heart Attack (Myocardial Infarction)",
        probability: "medium",
        icd10: "I21",
        description: "Blockage in a coronary artery cutting off blood supply to the heart muscle.",
        symptoms: ["chest_pain", "pain_radiating_to_arm", "shortness_of_breath", "cold_sweat", "nausea", "dizziness"],
        urgency: "emergency",
        care: "EMERGENCY — Call 911/emergency services immediately. Chew aspirin if not allergic while waiting.",
        prevention: "Healthy lifestyle, manage risk factors (BP, cholesterol, diabetes), no smoking.",
        sources: ["WHO", "American Heart Association", "ESC Guidelines"]
      },
      {
        name: "Gastroesophageal Reflux (GERD)",
        probability: "high",
        icd10: "K21",
        description: "Acid reflux causing burning chest pain (heartburn) often after meals or lying down.",
        symptoms: ["chest_pain", "burning_sensation", "acid_taste", "difficulty_swallowing"],
        urgency: "low",
        care: "Antacids, elevate head during sleep, avoid trigger foods, small frequent meals.",
        prevention: "Maintain healthy weight, avoid fatty/spicy foods, no smoking, limit alcohol/caffeine.",
        sources: ["NHS", "Mayo Clinic", "ACG Guidelines"]
      },
      {
        name: "Pulmonary Embolism",
        probability: "low",
        icd10: "I26",
        description: "Blood clot in the lungs causing sudden sharp chest pain and breathing difficulty.",
        symptoms: ["chest_pain", "shortness_of_breath", "rapid_heartbeat", "coughing_blood", "leg_swelling"],
        urgency: "emergency",
        care: "EMERGENCY — Call emergency services immediately. Requires anticoagulation therapy in hospital.",
        prevention: "Stay active, avoid long periods of immobility, compression stockings when traveling.",
        sources: ["WHO", "ESC Guidelines", "NIH"]
      }
    ]
  },

  abdominal_pain: {
    id: "abdominal_pain",
    name: "Abdominal Pain",
    category: "Gastrointestinal",
    relatedConditions: [
      {
        name: "Gastroenteritis",
        probability: "high",
        icd10: "K52.9",
        description: "Inflammation of the stomach and intestines, usually from viral or bacterial infection.",
        symptoms: ["abdominal_pain", "nausea", "vomiting", "diarrhea", "fever", "cramps"],
        urgency: "low",
        care: "Rest, oral rehydration salts, bland diet (BRAT). Seek care if symptoms persist >3 days.",
        prevention: "Hand hygiene, safe food handling, clean water, rotavirus vaccine for infants.",
        sources: ["WHO", "CDC", "NHS"]
      },
      {
        name: "Appendicitis",
        probability: "medium",
        icd10: "K37",
        description: "Inflammation of the appendix causing severe pain that starts around the navel and moves to lower right.",
        symptoms: ["abdominal_pain", "nausea", "vomiting", "fever", "loss_of_appetite", "rebound_tenderness"],
        urgency: "emergency",
        care: "EMERGENCY — Seek immediate surgical evaluation. Untreated appendicitis can be fatal.",
        prevention: "No known prevention. High-fiber diet may reduce risk.",
        sources: ["WHO", "NHS", "Mayo Clinic"]
      },
      {
        name: "Irritable Bowel Syndrome (IBS)",
        probability: "medium",
        icd10: "K58",
        description: "Chronic condition affecting the large intestine with cramping, bloating, and altered bowel habits.",
        symptoms: ["abdominal_pain", "bloating", "diarrhea", "constipation", "gas", "mucus_in_stool"],
        urgency: "low",
        care: "Dietary changes, stress management, fiber supplements, antispasmodics. Consult gastroenterologist.",
        prevention: "Manage stress, identify and avoid trigger foods, regular exercise, adequate sleep.",
        sources: ["NHS", "Mayo Clinic", "ACG Guidelines"]
      },
      {
        name: "Peptic Ulcer",
        probability: "medium",
        icd10: "K27",
        description: "Sores on the stomach lining or upper small intestine, often caused by H. pylori or NSAIDs.",
        symptoms: ["abdominal_pain", "burning_stomach_pain", "nausea", "bloating", "dark_stool", "vomiting_blood"],
        urgency: "medium",
        care: "Proton pump inhibitors, antibiotics for H. pylori, avoid NSAIDs and alcohol. Seek urgent care for blood in stool.",
        prevention: "Avoid excessive NSAIDs/aspirin, limit alcohol, treat H. pylori, manage stress.",
        sources: ["NHS", "Mayo Clinic", "ACG Guidelines"]
      }
    ]
  },

  fatigue: {
    id: "fatigue",
    name: "Fatigue / Extreme Tiredness",
    category: "General",
    relatedConditions: [
      {
        name: "Anemia",
        probability: "high",
        icd10: "D64.9",
        description: "Low red blood cell count or hemoglobin, reducing oxygen delivery throughout the body.",
        symptoms: ["fatigue", "weakness", "pale_skin", "shortness_of_breath", "dizziness", "cold_hands_feet"],
        urgency: "medium",
        care: "Iron supplements, dietary changes (leafy greens, lean meat). Requires blood test confirmation.",
        prevention: "Iron-rich diet, folate and B12 supplementation if needed, treat underlying causes.",
        sources: ["WHO", "NIH", "NHS"]
      },
      {
        name: "Hypothyroidism",
        probability: "medium",
        icd10: "E03.9",
        description: "Underactive thyroid gland producing insufficient thyroid hormone, slowing metabolism.",
        symptoms: ["fatigue", "weight_gain", "cold_sensitivity", "dry_skin", "hair_loss", "depression", "constipation"],
        urgency: "medium",
        care: "Thyroid hormone replacement therapy (levothyroxine). Requires medical diagnosis and monitoring.",
        prevention: "Adequate iodine intake, regular thyroid screening for high-risk groups.",
        sources: ["NHS", "Mayo Clinic", "ATA Guidelines"]
      },
      {
        name: "Diabetes (Type 2)",
        probability: "medium",
        icd10: "E11",
        description: "Chronic condition affecting blood sugar regulation, causing persistent fatigue and other symptoms.",
        symptoms: ["fatigue", "excessive_thirst", "frequent_urination", "blurred_vision", "slow_healing", "weight_loss"],
        urgency: "medium",
        care: "Blood glucose monitoring, dietary changes, exercise, medication. Requires medical diagnosis.",
        prevention: "Healthy weight, regular exercise, balanced diet, regular blood glucose screening.",
        sources: ["WHO", "IDF", "ADA Guidelines"]
      },
      {
        name: "Chronic Fatigue Syndrome (CFS/ME)",
        probability: "low",
        icd10: "G93.3",
        description: "Complex disorder characterized by extreme fatigue not explained by underlying medical conditions.",
        symptoms: ["fatigue", "post_exertional_malaise", "sleep_problems", "cognitive_difficulties", "muscle_pain"],
        urgency: "medium",
        care: "Pacing strategies, cognitive behavioral therapy, symptom management. Requires specialist evaluation.",
        prevention: "No known prevention. Avoid overexertion, stress management.",
        sources: ["NIH", "NHS", "CDC"]
      }
    ]
  },

  shortness_of_breath: {
    id: "shortness_of_breath",
    name: "Shortness of Breath",
    category: "Respiratory/Cardiovascular",
    relatedConditions: [
      {
        name: "Asthma Attack",
        probability: "high",
        icd10: "J45.901",
        description: "Sudden worsening of asthma symptoms causing severe breathing difficulty.",
        symptoms: ["shortness_of_breath", "wheezing", "chest_tightness", "cough"],
        urgency: "high",
        care: "Use rescue inhaler immediately. Seek emergency care if no improvement within 15 minutes.",
        prevention: "Follow asthma action plan, carry rescue inhaler, avoid triggers.",
        sources: ["WHO", "GINA Guidelines", "NHS"]
      },
      {
        name: "COPD",
        probability: "medium",
        icd10: "J44",
        description: "Chronic obstructive pulmonary disease causing progressive breathing difficulty.",
        symptoms: ["shortness_of_breath", "chronic_cough", "wheezing", "frequent_respiratory_infections"],
        urgency: "medium",
        care: "Bronchodilators, pulmonary rehab, oxygen therapy in severe cases. Quit smoking immediately.",
        prevention: "No smoking, avoid air pollutants, occupational hazard protection.",
        sources: ["WHO", "GOLD Guidelines", "NHS"]
      },
      {
        name: "Heart Failure",
        probability: "medium",
        icd10: "I50",
        description: "Heart unable to pump enough blood, causing fluid buildup in lungs.",
        symptoms: ["shortness_of_breath", "fatigue", "leg_swelling", "rapid_heartbeat", "persistent_cough"],
        urgency: "high",
        care: "Requires medical evaluation. Diuretics, ACE inhibitors, beta-blockers. Seek urgent care for sudden worsening.",
        prevention: "Manage BP, cholesterol, diabetes. Healthy lifestyle, no smoking.",
        sources: ["WHO", "ESC Guidelines", "AHA"]
      }
    ]
  },

  rash: {
    id: "rash",
    name: "Skin Rash",
    category: "Dermatological",
    relatedConditions: [
      {
        name: "Allergic Reaction",
        probability: "high",
        icd10: "L50.0",
        description: "Skin response to an allergen — may appear as hives, redness, or itchy bumps.",
        symptoms: ["rash", "itching", "swelling", "redness", "hives"],
        urgency: "medium",
        care: "Antihistamines, avoid the allergen. Seek emergency care if throat swelling or breathing difficulty occurs (anaphylaxis).",
        prevention: "Identify and avoid allergens, carry epinephrine auto-injector if prescribed.",
        sources: ["WHO", "AAAAI", "NHS"]
      },
      {
        name: "Eczema (Atopic Dermatitis)",
        probability: "medium",
        icd10: "L20",
        description: "Chronic inflammatory skin condition causing itchy, dry, inflamed patches.",
        symptoms: ["rash", "itching", "dry_skin", "red_patches", "scaly_skin", "skin_thickening"],
        urgency: "low",
        care: "Moisturizers, topical corticosteroids, antihistamines. Avoid known triggers.",
        prevention: "Regular moisturizing, identify triggers, gentle skincare, avoid harsh soaps.",
        sources: ["NHS", "AAD", "NICE Guidelines"]
      },
      {
        name: "Chickenpox (Varicella)",
        probability: "medium",
        icd10: "B01",
        description: "Highly contagious viral infection causing itchy blister-like rash all over the body.",
        symptoms: ["rash", "blisters", "itching", "fever", "fatigue", "loss_of_appetite"],
        urgency: "medium",
        care: "Calamine lotion, antihistamines, paracetamol (no aspirin for children). Isolate until blisters crust.",
        prevention: "Varicella vaccine (2 doses), avoid contact with infected persons.",
        sources: ["WHO", "CDC", "NHS"]
      },
      {
        name: "Measles",
        probability: "low",
        icd10: "B05",
        description: "Highly contagious viral disease with red blotchy rash spreading from face downward.",
        symptoms: ["rash", "high_fever", "cough", "runny_nose", "red_eyes", "white_spots_in_mouth"],
        urgency: "high",
        care: "Supportive care, vitamin A supplementation, rest, fluids. Isolate and contact health authority.",
        prevention: "MMR vaccine is 97% effective. Routine childhood immunization.",
        sources: ["WHO", "CDC", "UNICEF"]
      }
    ]
  },

  dizziness: {
    id: "dizziness",
    name: "Dizziness / Vertigo",
    category: "Neurological",
    relatedConditions: [
      {
        name: "Benign Paroxysmal Positional Vertigo (BPPV)",
        probability: "high",
        icd10: "H81.1",
        description: "Brief, intense episodes of dizziness triggered by specific head movements.",
        symptoms: ["dizziness", "spinning_sensation", "nausea", "nystagmus"],
        urgency: "low",
        care: "Epley maneuver (repositioning therapy). Consult an ENT or neurologist.",
        prevention: "No reliable prevention. Avoid rapid head movements if susceptible.",
        sources: ["NIH", "Mayo Clinic", "AAO-HNS Guidelines"]
      },
      {
        name: "Hypotension (Low Blood Pressure)",
        probability: "medium",
        icd10: "I95",
        description: "Blood pressure drop causing lightheadedness, especially when standing up.",
        symptoms: ["dizziness", "lightheadedness", "blurred_vision", "fainting", "fatigue"],
        urgency: "medium",
        care: "Increase fluid/salt intake, rise slowly from sitting/lying, compression stockings. Consult doctor.",
        prevention: "Stay hydrated, avoid prolonged standing, reduce alcohol, monitor medications.",
        sources: ["Mayo Clinic", "NHS", "AHA"]
      },
      {
        name: "Stroke / TIA",
        probability: "low",
        icd10: "I63",
        description: "Brain blood supply interruption — sudden dizziness with neurological symptoms is an emergency.",
        symptoms: ["dizziness", "sudden_severe_headache", "vision_changes", "facial_drooping", "arm_weakness", "speech_difficulty"],
        urgency: "emergency",
        care: "EMERGENCY — Call 911 immediately. Use FAST acronym: Face drooping, Arm weakness, Speech difficulty, Time to call.",
        prevention: "Manage BP, cholesterol, diabetes, no smoking, healthy lifestyle, anticoagulants if prescribed.",
        sources: ["WHO", "American Stroke Association", "ESC Guidelines"]
      }
    ]
  },

  joint_pain: {
    id: "joint_pain",
    name: "Joint Pain / Arthralgia",
    category: "Musculoskeletal",
    relatedConditions: [
      {
        name: "Osteoarthritis",
        probability: "high",
        icd10: "M19.9",
        description: "Degenerative joint disease from cartilage breakdown, common in older adults.",
        symptoms: ["joint_pain", "joint_stiffness", "swelling", "decreased_range_of_motion", "grating_sensation"],
        urgency: "low",
        care: "Physical therapy, pain relief (paracetamol, NSAIDs), weight management, assistive devices.",
        prevention: "Maintain healthy weight, regular low-impact exercise, protect joints from injury.",
        sources: ["WHO", "OARSI Guidelines", "NICE"]
      },
      {
        name: "Rheumatoid Arthritis",
        probability: "medium",
        icd10: "M06.9",
        description: "Autoimmune disease causing chronic joint inflammation, often affecting multiple joints symmetrically.",
        symptoms: ["joint_pain", "morning_stiffness", "swelling", "fatigue", "fever", "symmetrical_joint_involvement"],
        urgency: "medium",
        care: "DMARDs (methotrexate), NSAIDs, corticosteroids. Requires rheumatologist evaluation.",
        prevention: "No known prevention. Non-smoking reduces risk. Early treatment prevents joint damage.",
        sources: ["WHO", "ACR Guidelines", "EULAR Guidelines"]
      },
      {
        name: "Gout",
        probability: "medium",
        icd10: "M10",
        description: "Uric acid crystals depositing in joints causing sudden severe pain, often in the big toe.",
        symptoms: ["joint_pain", "sudden_severe_pain", "redness", "warmth", "swelling", "tenderness"],
        urgency: "medium",
        care: "NSAIDs/colchicine for acute attacks, allopurinol for prevention. Low-purine diet.",
        prevention: "Limit red meat/shellfish, reduce alcohol (especially beer), stay hydrated, healthy weight.",
        sources: ["ACR Guidelines", "EULAR Guidelines", "NHS"]
      }
    ]
  },

  nausea: {
    id: "nausea",
    name: "Nausea / Vomiting",
    category: "Gastrointestinal",
    relatedConditions: [
      {
        name: "Food Poisoning",
        probability: "high",
        icd10: "A05.9",
        description: "Illness from eating contaminated food, causing nausea, vomiting, and diarrhea.",
        symptoms: ["nausea", "vomiting", "diarrhea", "abdominal_cramps", "fever"],
        urgency: "medium",
        care: "Oral rehydration, rest, bland food when tolerated. Seek care if symptoms last >3 days or severe dehydration.",
        prevention: "Safe food handling, proper cooking temperatures, refrigeration, hand hygiene.",
        sources: ["WHO", "CDC", "FDA"]
      },
      {
        name: "Pregnancy (Morning Sickness)",
        probability: "medium",
        icd10: "O21.0",
        description: "Nausea and vomiting are common in early pregnancy, usually in the first trimester.",
        symptoms: ["nausea", "vomiting", "food_aversions", "fatigue"],
        urgency: "low",
        care: "Small frequent meals, ginger tea, vitamin B6, anti-nausea medications if needed. Consult OB/GYN.",
        prevention: "N/A (physiological process). Avoid trigger foods and smells.",
        sources: ["WHO", "ACOG Guidelines", "NHS"]
      },
      {
        name: "Gastritis",
        probability: "medium",
        icd10: "K29.7",
        description: "Inflammation of the stomach lining causing nausea, upper abdominal pain, and bloating.",
        symptoms: ["nausea", "vomiting", "upper_abdominal_pain", "bloating", "loss_of_appetite"],
        urgency: "medium",
        care: "Antacids, PPIs, avoid NSAIDs/alcohol. Test for H. pylori if suspected.",
        prevention: "Avoid excessive alcohol/NSAIDs, manage stress, limit spicy foods, treat H. pylori.",
        sources: ["NHS", "ACG Guidelines", "Mayo Clinic"]
      }
    ]
  }
};

/**
 * Urgency color and action mapping
 */
const urgencyConfig = {
  low: {
    label: "Low Urgency",
    color: "#22c55e",
    bgColor: "#f0fdf4",
    borderColor: "#86efac",
    icon: "✅",
    action: "Self-care at home. Monitor symptoms and consult a doctor if worsening."
  },
  medium: {
    label: "Moderate Urgency",
    color: "#f59e0b",
    bgColor: "#fffbeb",
    borderColor: "#fcd34d",
    icon: "⚠️",
    action: "Schedule a doctor's appointment within 24–48 hours. Monitor for worsening symptoms."
  },
  high: {
    label: "High Urgency",
    color: "#ef4444",
    bgColor: "#fef2f2",
    borderColor: "#fca5a5",
    icon: "🚨",
    action: "Seek medical care today. Go to an urgent care clinic or emergency room if necessary."
  },
  emergency: {
    label: "EMERGENCY",
    color: "#7c3aed",
    bgColor: "#faf5ff",
    borderColor: "#c4b5fd",
    icon: "🆘",
    action: "CALL EMERGENCY SERVICES (911/112/999) IMMEDIATELY. Do not wait."
  }
};

/**
 * Trusted medical sources
 */
const trustedSources = [
  { name: "World Health Organization (WHO)", url: "https://www.who.int", type: "International" },
  { name: "Centers for Disease Control (CDC)", url: "https://www.cdc.gov", type: "US Government" },
  { name: "National Institutes of Health (NIH)", url: "https://www.nih.gov", type: "US Government" },
  { name: "NHS (UK National Health Service)", url: "https://www.nhs.uk", type: "UK Government" },
  { name: "Mayo Clinic", url: "https://www.mayoclinic.org", type: "Medical Journal" },
  { name: "American Heart Association", url: "https://www.heart.org", type: "Medical Society" },
  { name: "European Society of Cardiology", url: "https://www.escardio.org", type: "Medical Society" },
  { name: "American College of Rheumatology", url: "https://www.rheumatology.org", type: "Medical Society" }
];

/**
 * Get all available symptoms
 */
function getAllSymptoms() {
  return Object.keys(symptomDatabase).map(key => ({
    id: key,
    name: symptomDatabase[key].name,
    category: symptomDatabase[key].category
  }));
}

/**
 * Analyze symptoms and return probable conditions
 * @param {string[]} symptoms - Array of symptom IDs
 * @param {object} patientInfo - Age, gender, existing conditions
 */
function analyzeSymptoms(symptoms, patientInfo = {}) {
  const conditionScores = {};
  const matchedSources = new Set();

  symptoms.forEach(symptomId => {
    const symptomData = symptomDatabase[symptomId];
    if (!symptomData) return;

    symptomData.relatedConditions.forEach(condition => {
      const key = condition.name;
      if (!conditionScores[key]) {
        conditionScores[key] = {
          ...condition,
          matchedSymptoms: [],
          score: 0
        };
      }

      conditionScores[key].matchedSymptoms.push(symptomId);

      // Scoring logic
      let baseScore = condition.probability === "high" ? 30 : condition.probability === "medium" ? 20 : 10;

      // Boost score for symptom overlap
      const overlapCount = condition.symptoms.filter(s => symptoms.includes(s)).length;
      const overlapBonus = (overlapCount / condition.symptoms.length) * 40;

      conditionScores[key].score += baseScore + overlapBonus;
      condition.sources.forEach(s => matchedSources.add(s));
    });
  });

  // Sort by score descending
  const sortedConditions = Object.values(conditionScores)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5); // Return top 5

  // Determine highest urgency level
  const urgencyOrder = { emergency: 4, high: 3, medium: 2, low: 1 };
  const highestUrgency = sortedConditions.reduce((max, c) => {
    return urgencyOrder[c.urgency] > urgencyOrder[max] ? c.urgency : max;
  }, "low");

  return {
    analyzedSymptoms: symptoms,
    probableConditions: sortedConditions,
    highestUrgency,
    urgencyInfo: urgencyConfig[highestUrgency],
    sources: trustedSources.filter(s => matchedSources.has(s.name.split(" (")[0]) ||
      [...matchedSources].some(m => s.name.includes(m))),
    disclaimer: "This tool provides general health information for educational purposes only and does NOT constitute medical advice, diagnosis, or treatment. Always consult a qualified healthcare professional for medical concerns.",
    generatedAt: new Date().toISOString()
  };
}

module.exports = { symptomDatabase, analyzeSymptoms, getAllSymptoms, urgencyConfig, trustedSources };
