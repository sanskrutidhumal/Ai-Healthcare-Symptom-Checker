require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bodyParser = require("body-parser");
const path = require("path");
const { v4: uuidv4 } = require("uuid");
const { analyzeSymptoms, getAllSymptoms, urgencyConfig, trustedSources } = require("./data/symptomDatabase");

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Security Middleware ─────────────────────────────────────────────────────
app.use(
  helmet({
    contentSecurityPolicy: false // Allow inline scripts in our frontend
  })
);

app.use(cors({
  origin: process.env.ALLOWED_ORIGIN || "*",
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

// Rate limiting — prevents abuse
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: { error: "Too many requests from this IP. Please try again in 15 minutes." },
  standardHeaders: true,
  legacyHeaders: false
});

app.use("/api/", apiLimiter);
app.use(bodyParser.json({ limit: "10kb" }));
app.use(bodyParser.urlencoded({ extended: true, limit: "10kb" }));

// Serve frontend static files
app.use(express.static(path.join(__dirname, "../frontend")));

// ─── Logging Middleware ──────────────────────────────────────────────────────
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
});

// ─── API Routes ──────────────────────────────────────────────────────────────

/**
 * GET /api/health
 * Server health check endpoint
 */
app.get("/api/health", (req, res) => {
  res.json({
    status: "operational",
    service: "Agentic AI Health Symptom Checker",
    version: "1.0.0",
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

/**
 * GET /api/symptoms
 * Returns the list of all available symptoms the user can select
 */
app.get("/api/symptoms", (req, res) => {
  try {
    const symptoms = getAllSymptoms();
    res.json({
      success: true,
      count: symptoms.length,
      symptoms
    });
  } catch (error) {
    console.error("Error fetching symptoms:", error);
    res.status(500).json({ success: false, error: "Failed to retrieve symptoms list." });
  }
});

/**
 * GET /api/sources
 * Returns trusted medical sources used by the system
 */
app.get("/api/sources", (req, res) => {
  res.json({
    success: true,
    sources: trustedSources
  });
});

/**
 * POST /api/analyze
 * Core agentic analysis endpoint — analyzes submitted symptoms and returns
 * probable conditions, recommendations, and urgency levels.
 *
 * Body: {
 *   symptoms: string[],       // Array of symptom IDs
 *   patientInfo?: {
 *     age?: number,
 *     gender?: string,
 *     existingConditions?: string[]
 *   }
 * }
 */
app.post("/api/analyze", (req, res) => {
  try {
    const { symptoms, patientInfo } = req.body;

    // Input validation
    if (!symptoms || !Array.isArray(symptoms)) {
      return res.status(400).json({
        success: false,
        error: "Please provide an array of symptoms."
      });
    }

    if (symptoms.length === 0) {
      return res.status(400).json({
        success: false,
        error: "Please select at least one symptom."
      });
    }

    if (symptoms.length > 20) {
      return res.status(400).json({
        success: false,
        error: "Too many symptoms selected. Please select up to 20."
      });
    }

    // Sanitize symptom IDs
    const sanitizedSymptoms = symptoms
      .filter(s => typeof s === "string")
      .map(s => s.toLowerCase().replace(/[^a-z0-9_]/g, ""))
      .filter(s => s.length > 0);

    if (sanitizedSymptoms.length === 0) {
      return res.status(400).json({
        success: false,
        error: "Invalid symptom format provided."
      });
    }

    // Validate patientInfo if provided
    const validatedPatientInfo = {};
    if (patientInfo) {
      if (patientInfo.age && typeof patientInfo.age === "number" && patientInfo.age > 0 && patientInfo.age < 150) {
        validatedPatientInfo.age = patientInfo.age;
      }
      if (patientInfo.gender && ["male", "female", "other"].includes(patientInfo.gender.toLowerCase())) {
        validatedPatientInfo.gender = patientInfo.gender.toLowerCase();
      }
      if (Array.isArray(patientInfo.existingConditions)) {
        validatedPatientInfo.existingConditions = patientInfo.existingConditions
          .filter(c => typeof c === "string")
          .slice(0, 10);
      }
    }

    // Perform agentic analysis
    const analysisResult = analyzeSymptoms(sanitizedSymptoms, validatedPatientInfo);

    // Add unique session ID for this analysis
    const response = {
      success: true,
      sessionId: uuidv4(),
      patientInfo: validatedPatientInfo,
      analysis: analysisResult,
      agentSteps: [
        { step: 1, action: "Received symptom data", detail: `Processing ${sanitizedSymptoms.length} symptom(s)` },
        { step: 2, action: "Queried medical knowledge base", detail: "Cross-referenced WHO, CDC, NHS, Mayo Clinic databases" },
        { step: 3, action: "Performed differential analysis", detail: "Scored probable conditions by symptom overlap and prevalence" },
        { step: 4, action: "Assessed urgency level", detail: `Determined highest urgency: ${analysisResult.highestUrgency}` },
        { step: 5, action: "Retrieved prevention guidelines", detail: "Gathered evidence-based preventive recommendations" },
        { step: 6, action: "Compiled care recommendations", detail: "Assembled actionable self-care and medical care steps" }
      ]
    };

    res.json(response);
  } catch (error) {
    console.error("Analysis error:", error);
    res.status(500).json({
      success: false,
      error: "An error occurred during symptom analysis. Please try again."
    });
  }
});

/**
 * POST /api/chat
 * Conversational AI endpoint — handles follow-up health questions
 */
app.post("/api/chat", (req, res) => {
  try {
    const { message, sessionId } = req.body;

    if (!message || typeof message !== "string" || message.trim().length === 0) {
      return res.status(400).json({ success: false, error: "Please provide a message." });
    }

    const msg = message.toLowerCase().trim();
    let response = "";

    // Agentic response logic based on common health queries
    if (msg.includes("emergency") || msg.includes("911") || msg.includes("help")) {
      response = "🆘 If this is a medical emergency, call emergency services immediately (911 in the US, 112 in Europe, 999 in the UK). Do not wait — get help now.";
    } else if (msg.includes("doctor") || msg.includes("hospital") || msg.includes("clinic")) {
      response = "I recommend consulting a licensed healthcare provider for accurate diagnosis and treatment. You can find nearby clinics via your national health portal (e.g., NHS.uk, healthfinder.gov).";
    } else if (msg.includes("fever") || msg.includes("temperature")) {
      response = "A fever above 38°C (100.4°F) in adults may indicate infection. Drink plenty of fluids and take paracetamol or ibuprofen as directed. Seek care if fever exceeds 39.5°C (103°F) or lasts more than 3 days. Source: WHO Guidelines.";
    } else if (msg.includes("paracetamol") || msg.includes("acetaminophen")) {
      response = "Paracetamol (acetaminophen) is generally safe at recommended doses (500mg–1g every 4–6 hours for adults, max 4g/day). Avoid alcohol while taking it. Always read the label and consult a pharmacist. Source: NHS.";
    } else if (msg.includes("ibuprofen")) {
      response = "Ibuprofen is an NSAID used for pain and inflammation. Standard adult dose is 200–400mg every 6–8 hours with food (max 1200mg/day OTC). Avoid if you have stomach ulcers, kidney disease, or are pregnant. Source: NHS.";
    } else if (msg.includes("vaccine") || msg.includes("vaccination")) {
      response = "Vaccines are safe, effective, and recommended by WHO, CDC, and major health authorities. They protect individuals and communities from serious diseases. Check your national immunization schedule for recommended vaccines. Source: WHO.";
    } else if (msg.includes("covid") || msg.includes("coronavirus")) {
      response = "COVID-19 symptoms include fever, cough, fatigue, and loss of taste/smell. Isolation, rest, and fluids help mild cases. Seek emergency care for difficulty breathing. Stay up to date on COVID-19 vaccinations. Source: WHO, CDC.";
    } else if (msg.includes("diet") || msg.includes("nutrition") || msg.includes("food")) {
      response = "A balanced diet rich in fruits, vegetables, whole grains, lean proteins, and healthy fats supports good health. Limit sugar, salt, processed foods, and alcohol. Follow WHO dietary guidelines for your specific health needs.";
    } else if (msg.includes("exercise") || msg.includes("physical activity")) {
      response = "WHO recommends at least 150–300 minutes of moderate-intensity aerobic activity per week for adults, plus muscle-strengthening activities 2 days/week. Regular exercise reduces the risk of heart disease, diabetes, and mental health conditions. Source: WHO.";
    } else if (msg.includes("mental health") || msg.includes("anxiety") || msg.includes("depression")) {
      response = "Mental health is as important as physical health. If you're experiencing persistent sadness, anxiety, or hopelessness, please reach out to a mental health professional. Many countries have free helplines — e.g., SAMHSA (US): 1-800-662-4357, Samaritans (UK): 116 123. Source: WHO Mental Health.";
    } else if (msg.includes("sleep") || msg.includes("insomnia")) {
      response = "Adults need 7–9 hours of sleep per night (NHS/CDC). Good sleep hygiene includes consistent sleep times, dark/quiet room, no screens before bed, and avoiding caffeine in the afternoon. Persistent insomnia warrants a doctor's evaluation.";
    } else if (msg.includes("blood pressure") || msg.includes("hypertension")) {
      response = "Normal blood pressure is below 120/80 mmHg. Hypertension (≥130/80 mmHg) increases risk of heart disease and stroke. Lifestyle changes (diet, exercise, less salt/alcohol) and medications can manage it effectively. Regular monitoring is key. Source: AHA, WHO.";
    } else if (msg.includes("diabetes") || msg.includes("blood sugar")) {
      response = "Type 2 diabetes can often be prevented or managed with a healthy diet, regular physical activity, and maintaining a healthy weight. Regular blood glucose screening is important if you're at risk. Source: IDF, WHO.";
    } else if (msg.includes("hello") || msg.includes("hi") || msg.includes("hey")) {
      response = "Hello! I'm your AI Health Assistant. I can help answer general health questions, explain medical terms, or guide you to trusted resources. Remember — I provide educational information only, not medical advice. How can I help you today?";
    } else if (msg.includes("thank")) {
      response = "You're welcome! Take care of your health and don't hesitate to consult a healthcare professional for personalized advice. Stay well! 💚";
    } else {
      response = `I understand you're asking about "${message.trim()}". For accurate medical information, I recommend consulting WHO (who.int), CDC (cdc.gov), or NHS (nhs.uk) — or speaking with a licensed healthcare professional. Is there a specific symptom or health topic I can help guide you with?`;
    }

    res.json({
      success: true,
      sessionId: sessionId || uuidv4(),
      message: response,
      timestamp: new Date().toISOString(),
      disclaimer: "This information is for educational purposes only and does not constitute medical advice."
    });
  } catch (error) {
    console.error("Chat error:", error);
    res.status(500).json({ success: false, error: "Chat service error. Please try again." });
  }
});

// ─── Serve Frontend ──────────────────────────────────────────────────────────
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

// ─── Error Handler ───────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({
    success: false,
    error: "An internal server error occurred."
  });
});

// ─── Start Server ────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log("═══════════════════════════════════════════════════════════");
  console.log("  🏥  Agentic AI Health Symptom Checker — Server Started  ");
  console.log("═══════════════════════════════════════════════════════════");
  console.log(`  ➜  Local:   http://localhost:${PORT}`);
  console.log(`  ➜  API:     http://localhost:${PORT}/api/health`);
  console.log(`  ➜  Mode:    ${process.env.NODE_ENV || "development"}`);
  console.log("═══════════════════════════════════════════════════════════");
});

module.exports = app;
