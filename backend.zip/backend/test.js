/**
 * HealthAI Backend — API Test Suite
 * Run: node backend/test.js
 */

const http = require("http");

const BASE = "http://localhost:3000";
let passed = 0;
let failed = 0;

function request(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: "localhost",
      port: 3000,
      path,
      method,
      headers: { "Content-Type": "application/json" }
    };

    const req = http.request(options, (res) => {
      let data = "";
      res.on("data", chunk => (data += chunk));
      res.on("end", () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, body: data }); }
      });
    });

    req.on("error", reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

function test(name, fn) {
  return fn().then(() => {
    console.log(`  ✅ PASS: ${name}`);
    passed++;
  }).catch(err => {
    console.log(`  ❌ FAIL: ${name} — ${err.message}`);
    failed++;
  });
}

function assert(condition, message) {
  if (!condition) throw new Error(message || "Assertion failed");
}

async function runTests() {
  console.log("\n═════════════════════════════════════════════");
  console.log("  🧪 HealthAI Backend — API Test Suite");
  console.log("═════════════════════════════════════════════\n");

  // Health check
  await test("GET /api/health returns operational status", async () => {
    const { status, body } = await request("GET", "/api/health");
    assert(status === 200, `Expected 200, got ${status}`);
    assert(body.status === "operational", `Expected operational, got ${body.status}`);
    assert(body.service === "Agentic AI Health Symptom Checker", "Wrong service name");
  });

  // Symptoms list
  await test("GET /api/symptoms returns symptom list", async () => {
    const { status, body } = await request("GET", "/api/symptoms");
    assert(status === 200, `Expected 200, got ${status}`);
    assert(body.success === true, "Expected success true");
    assert(Array.isArray(body.symptoms), "Expected symptoms array");
    assert(body.symptoms.length > 0, "Expected at least 1 symptom");
    assert(body.symptoms[0].id, "Expected symptom to have an id");
    assert(body.symptoms[0].name, "Expected symptom to have a name");
    assert(body.symptoms[0].category, "Expected symptom to have a category");
  });

  // Sources
  await test("GET /api/sources returns trusted sources", async () => {
    const { status, body } = await request("GET", "/api/sources");
    assert(status === 200, `Expected 200, got ${status}`);
    assert(body.success === true, "Expected success true");
    assert(Array.isArray(body.sources), "Expected sources array");
    assert(body.sources.length > 0, "Expected at least 1 source");
  });

  // Analyze — valid symptoms
  await test("POST /api/analyze with valid symptoms returns conditions", async () => {
    const { status, body } = await request("POST", "/api/analyze", {
      symptoms: ["cough", "fever"],
      patientInfo: { age: 30, gender: "female" }
    });
    assert(status === 200, `Expected 200, got ${status}`);
    assert(body.success === true, "Expected success true");
    assert(body.sessionId, "Expected sessionId");
    assert(body.analysis, "Expected analysis object");
    assert(Array.isArray(body.analysis.probableConditions), "Expected probableConditions array");
    assert(body.analysis.probableConditions.length > 0, "Expected at least 1 probable condition");
    assert(body.analysis.highestUrgency, "Expected highestUrgency");
    assert(body.analysis.disclaimer, "Expected disclaimer");
  });

  // Analyze — missing symptoms
  await test("POST /api/analyze with empty symptoms returns 400", async () => {
    const { status, body } = await request("POST", "/api/analyze", { symptoms: [] });
    assert(status === 400, `Expected 400, got ${status}`);
    assert(body.success === false, "Expected success false");
  });

  // Analyze — no symptoms field
  await test("POST /api/analyze with no symptoms field returns 400", async () => {
    const { status, body } = await request("POST", "/api/analyze", {});
    assert(status === 400, `Expected 400, got ${status}`);
    assert(body.success === false, "Expected success false");
  });

  // Chat — valid message
  await test("POST /api/chat with valid message returns response", async () => {
    const { status, body } = await request("POST", "/api/chat", {
      message: "What causes fever?"
    });
    assert(status === 200, `Expected 200, got ${status}`);
    assert(body.success === true, "Expected success true");
    assert(body.message && body.message.length > 0, "Expected non-empty message");
    assert(body.sessionId, "Expected sessionId");
    assert(body.disclaimer, "Expected disclaimer");
  });

  // Chat — emergency keywords
  await test("POST /api/chat with emergency keyword returns emergency info", async () => {
    const { status, body } = await request("POST", "/api/chat", {
      message: "emergency help"
    });
    assert(status === 200, `Expected 200, got ${status}`);
    assert(body.message.toLowerCase().includes("emergency"), "Expected emergency response");
  });

  // Chat — empty message
  await test("POST /api/chat with empty message returns 400", async () => {
    const { status, body } = await request("POST", "/api/chat", { message: "" });
    assert(status === 400, `Expected 400, got ${status}`);
    assert(body.success === false, "Expected success false");
  });

  // Full analysis with multiple symptoms
  await test("POST /api/analyze with multiple symptoms returns ranked conditions", async () => {
    const { status, body } = await request("POST", "/api/analyze", {
      symptoms: ["headache", "fever", "nausea", "fatigue"]
    });
    assert(status === 200, `Expected 200, got ${status}`);
    assert(body.analysis.probableConditions.length > 0, "Expected conditions");
    // Check conditions have required fields
    const c = body.analysis.probableConditions[0];
    assert(c.name, "Condition must have name");
    assert(c.description, "Condition must have description");
    assert(c.care, "Condition must have care guidance");
    assert(c.prevention, "Condition must have prevention guidance");
    assert(c.urgency, "Condition must have urgency level");
    assert(Array.isArray(c.sources), "Condition must have sources");
  });

  // Summary
  console.log("\n═════════════════════════════════════════════");
  console.log(`  Results: ${passed} passed, ${failed} failed`);
  console.log("═════════════════════════════════════════════\n");

  if (failed > 0) process.exit(1);
}

runTests().catch(err => {
  console.error("Test runner error:", err.message);
  console.error("Make sure the server is running: npm start");
  process.exit(1);
});
