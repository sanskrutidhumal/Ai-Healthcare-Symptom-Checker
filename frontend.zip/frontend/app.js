/**
 * HealthAI — Agentic Symptom Checker
 * Frontend Application Script
 * Connects to the Node.js/Express backend API
 */

// ─── Configuration ──────────────────────────────────────────────────────────
const API_BASE = window.location.origin;
const API = {
  health:   `${API_BASE}/api/health`,
  symptoms: `${API_BASE}/api/symptoms`,
  analyze:  `${API_BASE}/api/analyze`,
  chat:     `${API_BASE}/api/chat`,
  sources:  `${API_BASE}/api/sources`
};

// ─── State ───────────────────────────────────────────────────────────────────
let state = {
  allSymptoms: [],
  selectedSymptoms: [],
  chatSessionId: null,
  isAnalyzing: false,
  isChatLoading: false
};

// ─── Initialization ───────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  checkServerHealth();
  loadSymptoms();
});

// ─── Server Health Check ──────────────────────────────────────────────────────
async function checkServerHealth() {
  const dot   = document.getElementById("statusDot");
  const label = document.getElementById("statusLabel");

  try {
    const res  = await fetch(API.health);
    const data = await res.json();

    if (data.status === "operational") {
      dot.classList.add("online");
      label.textContent = "AI Online";
    } else {
      throw new Error("Not operational");
    }
  } catch {
    dot.classList.add("offline");
    label.textContent = "Offline";
  }
}

// ─── Tab Switching ────────────────────────────────────────────────────────────
function switchTab(tabId) {
  document.querySelectorAll(".tab-content").forEach(el => el.classList.remove("active"));
  document.querySelectorAll(".nav-btn").forEach(el => el.classList.remove("active"));
  document.getElementById(`tab-${tabId}`).classList.add("active");
  document.querySelector(`[data-tab="${tabId}"]`).classList.add("active");
}

// ─── Load Symptoms from API ───────────────────────────────────────────────────
async function loadSymptoms() {
  try {
    const res  = await fetch(API.symptoms);
    const data = await res.json();

    if (!data.success) throw new Error(data.error);

    state.allSymptoms = data.symptoms;
    renderSymptomCategories(data.symptoms);
  } catch (err) {
    console.error("Failed to load symptoms:", err);
    document.getElementById("symptomCategories").innerHTML = `
      <div style="color: var(--danger); padding: 16px; text-align: center;">
        <p>⚠️ Failed to load symptom database. Please refresh the page.</p>
        <button onclick="loadSymptoms()" style="margin-top: 8px; padding: 8px 16px; background: var(--primary); color: white; border: none; border-radius: 6px; cursor: pointer;">Retry</button>
      </div>`;
  }
}

// ─── Render Symptom Category Chips ───────────────────────────────────────────
function renderSymptomCategories(symptoms) {
  const container = document.getElementById("symptomCategories");

  // Group by category
  const grouped = {};
  symptoms.forEach(s => {
    if (!grouped[s.category]) grouped[s.category] = [];
    grouped[s.category].push(s);
  });

  const categoryIcons = {
    "Respiratory": "🫁",
    "General": "🌡️",
    "Neurological": "🧠",
    "Cardiovascular": "❤️",
    "Gastrointestinal": "🍽️",
    "Dermatological": "🩹",
    "Musculoskeletal": "🦴",
    "Respiratory/Cardiovascular": "💨"
  };

  container.innerHTML = Object.keys(grouped).map(category => `
    <div class="category-group" data-category="${category}">
      <div class="category-label">${categoryIcons[category] || "🔵"} ${category}</div>
      <div class="symptom-chips">
        ${grouped[category].map(s => `
          <div class="symptom-chip" id="chip-${s.id}" onclick="toggleSymptom('${s.id}', '${s.name}')">
            <span class="chip-check">✓</span>
            ${s.name}
          </div>
        `).join("")}
      </div>
    </div>
  `).join("");
}

// ─── Toggle Symptom Selection ─────────────────────────────────────────────────
function toggleSymptom(id, name) {
  const chip  = document.getElementById(`chip-${id}`);
  const index = state.selectedSymptoms.findIndex(s => s.id === id);

  if (index === -1) {
    // Add
    state.selectedSymptoms.push({ id, name });
    chip.classList.add("selected");
  } else {
    // Remove
    state.selectedSymptoms.splice(index, 1);
    chip.classList.remove("selected");
  }

  updateSelectedUI();
}

// ─── Update Selected Symptoms UI ─────────────────────────────────────────────
function updateSelectedUI() {
  const count = state.selectedSymptoms.length;

  // Update count badge
  document.getElementById("selectedCount").textContent = `${count} selected`;

  // Enable/disable analyze button
  const btn = document.getElementById("analyzeBtn");
  btn.disabled = count === 0;

  // Show/hide selected symptoms card
  const card = document.getElementById("selectedSymptomsCard");
  const hint = document.querySelector(".analyze-hint");
  card.style.display = count > 0 ? "block" : "none";
  hint.style.display = count > 0 ? "none" : "block";

  // Render tags
  const tagsEl = document.getElementById("selectedTags");
  tagsEl.innerHTML = state.selectedSymptoms.map(s => `
    <div class="selected-tag">
      ${s.name}
      <button class="tag-remove" onclick="removeSymptom('${s.id}')" title="Remove">×</button>
    </div>
  `).join("");
}

// ─── Remove a Single Symptom ──────────────────────────────────────────────────
function removeSymptom(id) {
  const chip  = document.getElementById(`chip-${id}`);
  const index = state.selectedSymptoms.findIndex(s => s.id === id);
  if (index !== -1) {
    state.selectedSymptoms.splice(index, 1);
    if (chip) chip.classList.remove("selected");
    updateSelectedUI();
  }
}

// ─── Clear All Symptoms ───────────────────────────────────────────────────────
function clearAllSymptoms() {
  state.selectedSymptoms.forEach(s => {
    const chip = document.getElementById(`chip-${s.id}`);
    if (chip) chip.classList.remove("selected");
  });
  state.selectedSymptoms = [];
  updateSelectedUI();
}

// ─── Filter Symptoms by Search ────────────────────────────────────────────────
function filterSymptoms(query) {
  const q = query.toLowerCase().trim();
  const groups = document.querySelectorAll(".category-group");

  groups.forEach(group => {
    let groupVisible = false;
    group.querySelectorAll(".symptom-chip").forEach(chip => {
      const text    = chip.textContent.trim().toLowerCase();
      const visible = !q || text.includes(q);
      chip.style.display = visible ? "" : "none";
      if (visible) groupVisible = true;
    });
    group.style.display = groupVisible ? "" : "none";
  });
}

// ─── Core: Analyze Symptoms ───────────────────────────────────────────────────
async function analyzeSymptoms() {
  if (state.selectedSymptoms.length === 0 || state.isAnalyzing) return;

  state.isAnalyzing = true;
  const btn = document.getElementById("analyzeBtn");
  btn.disabled = true;
  btn.innerHTML = `<div class="spinner" style="border-color: rgba(255,255,255,.3); border-top-color: white;"></div><span>Analyzing...</span>`;

  // Collect patient info
  const patientInfo = {};
  const age    = parseInt(document.getElementById("age").value);
  const gender = document.getElementById("gender").value;
  const conditions = document.getElementById("existingConditions").value
    .split(",").map(s => s.trim()).filter(Boolean);

  if (!isNaN(age) && age > 0) patientInfo.age = age;
  if (gender) patientInfo.gender = gender;
  if (conditions.length > 0) patientInfo.existingConditions = conditions;

  // Show loading state with AI steps
  showAnalysisLoading();

  try {
    const response = await fetch(API.analyze, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        symptoms: state.selectedSymptoms.map(s => s.id),
        patientInfo
      })
    });

    const data = await response.json();

    if (!data.success) throw new Error(data.error || "Analysis failed");

    // Simulate agent steps progression with real data
    await animateAgentSteps(data.analysis.agentSteps || data.agentSteps);

    // Render results
    renderAnalysisResults(data);

  } catch (err) {
    console.error("Analysis error:", err);
    showToast("Analysis failed: " + err.message, "error");
    resetResultsPanel();
  } finally {
    state.isAnalyzing = false;
    btn.disabled = false;
    btn.innerHTML = `<span class="btn-icon">🔬</span><span class="btn-text">Analyze Symptoms with AI</span>`;
  }
}

// ─── Show AI Loading Steps ────────────────────────────────────────────────────
function showAnalysisLoading() {
  document.getElementById("resultsPlaceholder").style.display  = "none";
  document.getElementById("analysisResults").style.display     = "none";
  document.getElementById("analysisLoading").style.display     = "block";

  const steps = [
    { action: "Receiving symptom data", detail: `Processing ${state.selectedSymptoms.length} symptom(s)` },
    { action: "Querying medical knowledge base", detail: "Cross-referencing WHO, CDC, NHS, Mayo Clinic databases" },
    { action: "Performing differential analysis", detail: "Scoring probable conditions by symptom overlap and prevalence" },
    { action: "Assessing urgency level", detail: "Determining required care urgency" },
    { action: "Retrieving prevention guidelines", detail: "Gathering evidence-based preventive recommendations" },
    { action: "Compiling care recommendations", detail: "Assembling actionable self-care and medical care steps" }
  ];

  document.getElementById("aiSteps").innerHTML = steps.map((s, i) => `
    <div class="ai-step" id="ai-step-${i}">
      <div class="step-num">${i + 1}</div>
      <div class="step-content">
        <div class="step-action">${s.action}</div>
        <div class="step-detail">${s.detail}</div>
      </div>
    </div>
  `).join("");
}

// ─── Animate Agent Steps ──────────────────────────────────────────────────────
async function animateAgentSteps(steps) {
  const delay = ms => new Promise(r => setTimeout(r, ms));

  for (let i = 0; i < 6; i++) {
    const el = document.getElementById(`ai-step-${i}`);
    if (!el) continue;

    // Mark previous as done
    if (i > 0) {
      const prev = document.getElementById(`ai-step-${i - 1}`);
      if (prev) {
        prev.classList.remove("active");
        prev.classList.add("done");
        prev.querySelector(".step-num").textContent = "✓";
      }
    }

    el.classList.add("active");
    await delay(350);
  }

  // Mark last as done
  const last = document.getElementById("ai-step-5");
  if (last) {
    last.classList.remove("active");
    last.classList.add("done");
    last.querySelector(".step-num").textContent = "✓";
  }

  await delay(200);
}

// ─── Render Analysis Results ──────────────────────────────────────────────────
function renderAnalysisResults(data) {
  document.getElementById("analysisLoading").style.display = "none";

  const { analysis, sessionId, patientInfo } = data;
  const { probableConditions, urgencyInfo, highestUrgency, sources, disclaimer, generatedAt } = analysis;

  const urgencyColors = {
    low:       { bg: "#f0fdf4", border: "#86efac", text: "#15803d" },
    medium:    { bg: "#fffbeb", border: "#fcd34d", text: "#92400e" },
    high:      { bg: "#fef2f2", border: "#fca5a5", text: "#991b1b" },
    emergency: { bg: "#faf5ff", border: "#c4b5fd", text: "#5b21b6" }
  };

  const uc = urgencyColors[highestUrgency] || urgencyColors.low;

  let html = `
    <div class="result-meta">
      <span>🔍 Session: <strong>${sessionId?.slice(0, 8)}...</strong></span>
      <span>📅 ${new Date(generatedAt).toLocaleString()}</span>
    </div>

    <!-- Urgency Banner -->
    <div class="urgency-banner" style="background:${uc.bg}; border-color:${uc.border}; color:${uc.text};">
      <span class="urgency-icon">${urgencyInfo.icon}</span>
      <div class="urgency-content">
        <div class="urgency-title">${urgencyInfo.label}</div>
        <div class="urgency-action">${urgencyInfo.action}</div>
      </div>
    </div>

    <!-- Disclaimer -->
    <div class="disclaimer-card">
      <span>⚠️</span>
      <span>${disclaimer}</span>
    </div>

    <!-- Probable Conditions -->
    <div class="conditions-section">
      <div class="section-title">
        🩺 Probable Conditions (${probableConditions.length} found)
      </div>
  `;

  if (probableConditions.length === 0) {
    html += `
      <div style="text-align:center; padding: 32px; color: var(--text-muted);">
        <p>No matching conditions found in our database for the selected symptoms.</p>
        <p style="margin-top: 8px;">Please consult a healthcare professional for evaluation.</p>
      </div>`;
  } else {
    probableConditions.forEach((condition, idx) => {
      const isFirst = idx === 0;
      const matchedNames = (condition.matchedSymptoms || [])
        .map(id => state.allSymptoms.find(s => s.id === id)?.name || id);

      html += `
        <div class="condition-card ${isFirst ? "expanded" : ""}" id="cond-${idx}">
          <div class="condition-header" onclick="toggleConditionCard(${idx})">
            <div>
              <div class="condition-name">${idx + 1}. ${condition.name}</div>
              ${condition.icd10 ? `<span class="icd-code">ICD-10: ${condition.icd10}</span>` : ""}
            </div>
            <div class="condition-meta">
              <span class="probability-badge ${condition.probability}">${condition.probability} probability</span>
              <span class="urgency-badge ${condition.urgency}">${condition.urgency}</span>
              <span class="expand-icon">▼</span>
            </div>
          </div>
          <div class="condition-body">
            <p class="condition-desc">${condition.description}</p>

            ${matchedNames.length > 0 ? `
              <div class="condition-section">
                <div class="condition-section-title">Matched Symptoms</div>
                <div class="matched-symptoms">
                  ${matchedNames.map(n => `<span class="matched-symptom-chip">${n}</span>`).join("")}
                </div>
              </div>` : ""}

            <div class="condition-section" style="background: #f0fdf4;">
              <div class="condition-section-title" style="color: var(--success);">💊 Care & Treatment</div>
              <div class="condition-section-text">${condition.care}</div>
            </div>

            <div class="condition-section" style="background: #eff6ff;">
              <div class="condition-section-title" style="color: var(--primary);">🛡️ Prevention</div>
              <div class="condition-section-text">${condition.prevention}</div>
            </div>

            <div class="condition-sources">
              ${(condition.sources || []).map(s => `<span class="source-chip">📚 ${s}</span>`).join("")}
            </div>
          </div>
        </div>
      `;
    });
  }

  html += `</div>`;

  // Sources section
  if (sources && sources.length > 0) {
    html += `
      <div class="sources-card">
        <h4>📚 Verified Medical Sources Used in This Analysis</h4>
        <div class="sources-grid">
          ${sources.map(s => `
            <a href="${s.url}" target="_blank" rel="noopener" class="source-tag">
              🔗 ${s.name}
            </a>
          `).join("")}
        </div>
      </div>`;
  }

  // Action buttons
  html += `
    <div style="display: flex; gap: 10px; margin-top: 16px;">
      <button onclick="window.print()" style="flex:1; padding: 10px; background: var(--surface-alt); border: 1px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; font-size: 14px;">
        🖨️ Print Report
      </button>
      <button onclick="clearAllSymptoms(); resetResultsPanel();" style="flex:1; padding: 10px; background: var(--surface-alt); border: 1px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; font-size: 14px;">
        🔄 New Analysis
      </button>
    </div>
  `;

  const resultsEl = document.getElementById("analysisResults");
  resultsEl.innerHTML = html;
  resultsEl.style.display = "block";

  // Scroll to results on mobile
  if (window.innerWidth < 900) {
    resultsEl.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

// ─── Toggle Condition Card Expand ─────────────────────────────────────────────
function toggleConditionCard(idx) {
  const card = document.getElementById(`cond-${idx}`);
  if (card) card.classList.toggle("expanded");
}

// ─── Reset Results Panel ──────────────────────────────────────────────────────
function resetResultsPanel() {
  document.getElementById("resultsPlaceholder").style.display = "block";
  document.getElementById("analysisLoading").style.display    = "none";
  document.getElementById("analysisResults").style.display    = "none";
}

// ─── Chat: Send Message ───────────────────────────────────────────────────────
async function sendChatMessage() {
  if (state.isChatLoading) return;

  const inputEl  = document.getElementById("chatInput");
  const message  = inputEl.value.trim();
  if (!message) return;

  inputEl.value = "";
  autoResize(inputEl);

  // Append user message
  appendChatMsg("user", message);
  showTypingIndicator();

  state.isChatLoading = true;
  document.getElementById("chatSendBtn").disabled = true;

  try {
    const res  = await fetch(API.chat, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        sessionId: state.chatSessionId
      })
    });

    const data = await res.json();
    removeTypingIndicator();

    if (!data.success) throw new Error(data.error);

    state.chatSessionId = data.sessionId;
    appendChatMsg("bot", data.message);

  } catch (err) {
    removeTypingIndicator();
    appendChatMsg("bot", "⚠️ Sorry, I'm having trouble responding right now. Please try again.");
    console.error("Chat error:", err);
  } finally {
    state.isChatLoading = false;
    document.getElementById("chatSendBtn").disabled = false;
    inputEl.focus();
  }
}

// ─── Append Chat Message ──────────────────────────────────────────────────────
function appendChatMsg(role, text) {
  const container = document.getElementById("chatMessages");

  const div = document.createElement("div");
  div.className = `chat-msg ${role}`;
  div.innerHTML = `
    <div class="msg-avatar">${role === "bot" ? "🤖" : "👤"}</div>
    <div class="msg-bubble">
      <p>${escapeHtml(text).replace(/\n/g, "<br>")}</p>
    </div>
  `;

  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

// ─── Suggestion Buttons ───────────────────────────────────────────────────────
function sendSuggestion(btn) {
  const text = btn.textContent.trim();
  document.getElementById("chatInput").value = text;
  sendChatMessage();
}

// ─── Typing Indicator ─────────────────────────────────────────────────────────
function showTypingIndicator() {
  const container = document.getElementById("chatMessages");
  const div = document.createElement("div");
  div.className = "chat-msg bot";
  div.id = "typingIndicator";
  div.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-bubble">
      <div class="typing-indicator">
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
      </div>
    </div>
  `;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function removeTypingIndicator() {
  const el = document.getElementById("typingIndicator");
  if (el) el.remove();
}

// ─── Chat Keyboard Handler ────────────────────────────────────────────────────
function handleChatKey(e) {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendChatMessage();
  }
}

// ─── Auto-resize Textarea ──────────────────────────────────────────────────────
function autoResize(el) {
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 120) + "px";
}

// ─── Toast Notification ───────────────────────────────────────────────────────
function showToast(msg, type = "") {
  const existing = document.querySelector(".toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

// ─── XSS Protection ───────────────────────────────────────────────────────────
function escapeHtml(str) {
  return String(str)
    .replace(/&/g,  "&amp;")
    .replace(/</g,  "&lt;")
    .replace(/>/g,  "&gt;")
    .replace(/"/g,  "&quot;")
    .replace(/'/g,  "&#039;");
}
